document.getElementById("Daftar").addEventListener("click", function() {
  setTimeout(function() {
    window.location.href = "main/daftar.html";
  }, 500); // jeda 2 detik
});

document.getElementById("Pinjam").addEventListener("click", function() {
  setTimeout(function() {
    window.location.href = "main/ajukan.html";
  }, 500); // jeda 2 detik
});

document.getElementById("Pembayaran").addEventListener("click", function() {
  setTimeout(function() {
    window.location.href = "main/pembayaran.html";
  }, 500); // jeda 2 detik
});

document.getElementById("Panduan").addEventListener("click", function() {
  setTimeout(function() {
    window.location.href = "main/panduan.html";
  }, 500); // jeda 2 detik
});